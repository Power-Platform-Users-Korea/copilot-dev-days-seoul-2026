# [한국어 실습 패키지] 한결전자(K-Retail) Power BI 에이전트 자동화 실습 파일

이 압축 파일은 유튜브 영상(Analytical Guy) 및 HTML 매뉴얼(`powerbi-agent-manual-wiki.html`)의 모든 과정을 **한국 리테일 도메인과 한글 컬럼명**으로 100% 동일하게 실습할 수 있도록 제작된 패키지입니다.

---

## 1. 포함된 파일 목록 (총 6개 파일)

1. **`Fact_Sales.csv` (매출 팩트 테이블 - 약 2,350건)**
   - 컬럼: `주문번호`, `주문항목번호`, `주문일자`, `배송완료일자`, `CustomerKey`, `StoreKey`, `ProductKey`, `주문수량`, `통화코드`
   - **핵심 설계 포인트**: 영상과 동일하게 `Fact_Sales`에는 **`주문수량`만 있고 판매 단가가 없습니다.** 에이전트가 `Power BI Authoring MCP`를 통해 스키마를 분석한 뒤, 스스로 `Dim_Products`의 `판매단가_KRW`와 `원가_KRW`를 찾아내어 `RELATED()` 함수로 DAX 측정값을 작성하도록 설계되어 있습니다.
2. **`Dim_Products.csv` (제품 차원 테이블 - 18개 한국 주력 가전/IT 제품)**
   - 컬럼: `ProductKey`, `제품명`, `카테고리`(컴퓨터/노트북, 모바일/태블릿, 대형가전 등), `하위카테고리`, `브랜드`(삼성전자, LG전자, 쿠쿠전자), `색상`, `원가_KRW`, `판매단가_KRW`
3. **`Dim_Stores.csv` (매장 차원 테이블 - 12개 국내 온/오프라인 매장)**
   - 컬럼: `StoreKey`, `매장명`(강남 본점, 여의도 더현대점, 판교 테크노밸리점, 공식 온라인몰 등), `권역`(서울, 수도권, 영남권, 온라인 등), `지역_시도`, `매장유형`, `매장면적_제곱미터`, `개점일`
4. **`Dim_Customers.csv` (고객 차원 테이블 - 200명 한국 고객)**
   - 컬럼: `CustomerKey`, `고객명`, `성별`, `연령대`, `거주지역`, `거주권역`, `고객등급`(VIP, 골드, 실버, 일반), `가입일`
5. **`Dim_Date.csv` (날짜 차원 테이블 - 2024년~2026년)**
   - 컬럼: `Date`, `연도`, `연도명`, `분기번호`, `분기`, `연도분기`, `월번호`, `월`, `연월`, `요일`, `평일주말구분`
6. **`Retail_IQ_Light_KR.json` (맑은 고딕/Pretendard 최적화 커스텀 브랜드 테마)**
   - 영상 후반부(34:20)의 커스텀 테마 적용 실습용 JSON 파일입니다.

---

## 2. 사전 준비: Power BI Desktop에서 `.pbip` 프로젝트 만들기 (3분 소요)

1. **Power BI Desktop**을 실행하고 `홈 > 텍스트/CSV`를 통해 위 **5개의 CSV 파일**(`Fact_Sales`, `Dim_Products`, `Dim_Stores`, `Dim_Customers`, `Dim_Date`)을 모두 불러옵니다 (`데이터 로드` 클릭).
2. 좌측 **모델 보기(Model View)** 탭으로 이동하여 아래와 같이 1:N 관계(Relationships) 4개가 연결되어 있는지 확인합니다 (자동 감지되거나 드래그로 연결):
   - `Dim_Products[ProductKey]` (1) ─── (*) `Fact_Sales[ProductKey]`
   - `Dim_Stores[StoreKey]` (1) ─── (*) `Fact_Sales[StoreKey]`
   - `Dim_Customers[CustomerKey]` (1) ─── (*) `Fact_Sales[CustomerKey]`
   - `Dim_Date[Date]` (1) ─── (*) `Fact_Sales[주문일자]`
3. 상단 메뉴에서 **`파일(File) > 다른 이름으로 저장(Save as)`**을 누르고, 파일 형식을 반드시 **`Power BI project files (*.pbip)`**로 선택합니다.
4. 파일 이름을 **`K_Retail_Sales_Demo.pbip`**로 지정하여 이 폴더 안에 저장하고, **Power BI Desktop 창을 닫지 말고 그대로 켜 둡니다.**

---

## 3. Claude Code / Copilot CLI 복사해서 바로 쓰는 한글 프롬프트

### [실습 1단계] MCP로 모델 연결 및 한글 KPI DAX 측정값 자동 생성
```text
현재 열려 있는 K_Retail_Sales_Demo.pbip 파일에 연결해 줘.
시맨틱 모델 스키마를 확인한 뒤, 대시보드 KPI 카드와 차트에 사용할 핵심 DAX 측정값들을 'KPI 측정값'이라는 별도 폴더 안에 생성하고 모델에서 검증해 줘.
(포함할 측정값 예시: 총매출액, 총원가, 매출총이익, 이익률(%), 총주문건수, 총판매수량, 고객당 평균매출, 전년 동기 대비 매출 성장률 YoY % 등)
```

### [실습 2단계] Authoring Skill로 4페이지 한글 대시보드 & 네비게이션 생성
```text
powerbi-authoring:powerbi-report-authoring 스킬을 사용해서 K_Retail_Sales_Demo.pbip 파일에 4페이지 분량의 한국어 경영진 리포트를 만들어 줘. 기존 빈 페이지는 삭제해도 돼.
각 페이지 구성은 다음과 같아:
- 1페이지: 경영진 종합 요약 (Executive Summary - 핵심 KPI 카드 5개, 월별 매출 추이, 카테고리별 성과, 연도 슬라이서)
- 2페이지: 제품 및 브랜드 분석 (Product Analysis - 카테고리/브랜드별 매출 및 이익률 비교)
- 3페이지: 권역 및 매장 분석 (Store Analysis - 서울/수도권/영남권/온라인 등 권역별 및 매장 유형별 성과)
- 4페이지: 고객 세그먼트 및 매출 비교 (Customer & Sales Comparison - 고객등급/연령대별 분석 및 전년 대비 비교)

리포트 상단에는 각 페이지로 이동할 수 있는 페이지 네비게이션(Page Navigator) 바를 추가하고, CLI 검증과 스크린샷 캡처 리뷰까지 완료해 줘.
```

### [실습 3단계] 한국형 브랜드 테마 JSON(`Retail_IQ_Light_KR.json`) 일괄 적용
```text
폴더 안에 있는 Retail_IQ_Light_KR.json 파일을 이 리포트의 커스텀 테마로 등록하고, 개별 비주얼에 하드코딩된 색상들을 새 테마 팔레트에 맞게 전체 재정비(Re-sweep)한 뒤 다시 검증해 줘.
```
